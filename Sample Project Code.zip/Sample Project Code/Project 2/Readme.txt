To Run the project. You need to use the following commad to install Yad:
----------------------------------
sudo apt-get update -y
sudo apt-get install -y yad
----------------------------------
Before opening Give permission to execute.
Run using following Command: ./project_name.sh
-------------------------------------
Thank you.